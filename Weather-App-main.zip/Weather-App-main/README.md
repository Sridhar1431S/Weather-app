I created Weather App using HTML,CSS and JavaScript
i uploded all the content her
